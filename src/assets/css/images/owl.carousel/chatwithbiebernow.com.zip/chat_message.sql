-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Nov 21, 2016 at 02:31 PM
-- Server version: 10.1.9-MariaDB
-- PHP Version: 5.6.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `new_pr`
--

-- --------------------------------------------------------

--
-- Table structure for table `chat_message`
--

CREATE TABLE `chat_message` (
  `id` int(11) NOT NULL,
  `msg_from` int(11) NOT NULL,
  `msg_to` int(11) NOT NULL,
  `msg` text NOT NULL,
  `sender_name` varchar(30) NOT NULL,
  `date_timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `chat_message`
--

INSERT INTO `chat_message` (`id`, `msg_from`, `msg_to`, `msg`, `sender_name`, `date_timestamp`) VALUES
(1, 5, 1, 'hello', '', '2016-11-21 12:39:40'),
(2, 5, 1, 'hello', '', '2016-11-21 12:42:59'),
(3, 5, 1, 'hjl', '', '2016-11-21 12:47:17'),
(4, 5, 1, 'bhkh', '', '2016-11-21 12:47:34'),
(5, 5, 1, '', '', '2016-11-21 12:47:42'),
(6, 5, 1, 'hhjkj', '', '2016-11-21 12:47:43'),
(7, 5, 1, 'g', '', '2016-11-21 12:48:08'),
(8, 5, 1, 'vgh', '', '2016-11-21 12:48:15'),
(9, 5, 1, 'fyjfg', '', '2016-11-21 12:48:42'),
(10, 5, 1, 'gh', '', '2016-11-21 12:51:13'),
(11, 5, 1, 'tgui', '', '2016-11-21 12:53:46'),
(12, 5, 1, 'ftu', '', '2016-11-21 12:53:46'),
(13, 5, 1, 'gtuy', '', '2016-11-21 12:53:49'),
(14, 5, 1, 'ty', '', '2016-11-21 12:53:50'),
(15, 5, 1, 'try', '', '2016-11-21 12:53:50'),
(16, 5, 1, 'rfth', '', '2016-11-21 12:53:50'),
(17, 5, 1, 'try', '', '2016-11-21 12:53:50'),
(18, 5, 1, 'ftyf', '', '2016-11-21 12:53:51'),
(19, 5, 1, 'tyf', '', '2016-11-21 12:53:51'),
(20, 5, 1, 'tyf', '', '2016-11-21 12:53:51'),
(21, 5, 1, 'ytf', '', '2016-11-21 12:53:51'),
(22, 5, 1, 'rty', '', '2016-11-21 12:53:51'),
(23, 5, 1, 'f', '', '2016-11-21 12:53:52'),
(24, 5, 1, 'tyf', '', '2016-11-21 12:53:52'),
(25, 5, 1, 'ty', '', '2016-11-21 12:53:52'),
(26, 5, 1, 'fy', '', '2016-11-21 12:53:52'),
(27, 5, 1, 'ty', '', '2016-11-21 12:53:53'),
(28, 5, 1, 'test', '', '2016-11-21 12:55:34'),
(29, 5, 1, 'test', '', '2016-11-21 12:59:31'),
(30, 5, 1, 'tset', '', '2016-11-21 13:01:04'),
(31, 5, 1, 'tweszte', '', '2016-11-21 13:01:41'),
(32, 5, 1, 'uigk', '', '2016-11-21 13:03:24'),
(33, 5, 1, 'testee', 'htht', '2016-11-21 13:08:52'),
(34, 5, 1, 'test', 'htht', '2016-11-21 13:12:01'),
(35, 5, 1, 'test', 'htht', '2016-11-21 13:12:25'),
(36, 5, 1, 'kk', 'htht', '2016-11-21 13:16:37'),
(37, 5, 1, 'll', 'htht', '2016-11-21 13:16:38'),
(38, 5, 1, 'kkk', 'htht', '2016-11-21 13:16:38'),
(39, 5, 1, 'kk', 'htht', '2016-11-21 13:16:40'),
(40, 5, 1, 'kll', 'htht', '2016-11-21 13:16:40'),
(41, 5, 1, 'fh', 'htht', '2016-11-21 13:18:21'),
(42, 5, 1, 'dfhf', 'htht', '2016-11-21 13:18:21'),
(43, 5, 1, 'fg', 'htht', '2016-11-21 13:18:22'),
(44, 5, 1, 'fgh', 'htht', '2016-11-21 13:18:23'),
(45, 5, 1, 'gfj', 'htht', '2016-11-21 13:18:24'),
(46, 5, 1, 'g', 'htht', '2016-11-21 13:18:24'),
(47, 5, 1, 'hj', 'htht', '2016-11-21 13:18:27'),
(48, 5, 1, 'fgh', 'htht', '2016-11-21 13:18:27'),
(49, 5, 1, 'twees', 'htht', '2016-11-21 13:24:59'),
(50, 5, 1, 'test', 'htht', '2016-11-21 13:28:00'),
(51, 5, 1, 'test', 'htht', '2016-11-21 13:28:06');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `chat_message`
--
ALTER TABLE `chat_message`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `chat_message`
--
ALTER TABLE `chat_message`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
