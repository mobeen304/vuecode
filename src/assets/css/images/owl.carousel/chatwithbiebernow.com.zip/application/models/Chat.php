<?php

class Chat extends CI_Model {


function login($user,$gender)
{
	$this->db->select('id');
	$this->db->where(array('name'=>$user));
	$query2 = $this->db->get('user');
	if($query2->num_rows()>0)
	{
		return $query2->row()->id;
	}else{
	$query = $this->db->insert('user',array('name'=>$user,'gender'=>$gender));
	//$query = $this->db->query("INSERT INTO user ('user') VALUES ('$user')");
	if($query)
	{
		$last_id = $this->db->insert_id();
$query1 = $this->db->insert('chat_session',array('user_id'=>$last_id,'rep_id'=>'0'));
		return $last_id;
			}else{
			return 'false';
		}
	}
}
function get_userinfo($id)
{

$query2 = $this->db->query("SELECT * FROM `user` WHERE `id`='$id'");
		if($query2->num_rows()>0)
		{
			return $query2->result_array();
		}else{
			return 'false';
		}

}
function send_msg($user_id,$admin,$msg,$sender_name,$role)
{
	  if($role=='admin')
{
	$this->db->where(array('user_id'=>$user_id,'rep_id'=>'0'));
	$this->db->update('chat_session',array('rep_id'=>$admin));
}
	$query = $this->db->insert('chat_message',array('user_id'=>$user_id,'admin'=>$admin,'msg'=>$msg,'sender_name'=>$sender_name));
	if($query)
	{ 
    
	       $last_id = $this->db->insert_id();
		   $this->db->where('id',$last_id);
	     	$query2 = $this->db->get("chat_message");
           if($query2->num_rows()>0)
           {
           	return $query2->row_array();
           }else
           {
           	return array('false');
           }
			}else{
		return array('false');
	}
}
function get_usermsg($id)
{
	$query2 = $this->db->query("SELECT * FROM `chat_message` WHERE `user_id`='$id'");
		if($query2->num_rows()>0)
		{
			return $query2->result_array();
		}else{
			return false;
		}
}
function admin_loginCheck($username,$password){
	$this->db->where(array('admin_log_name'=>$username,'admin_pass'=>$password));
$query = $this->db->get('admin_login');
if($query->num_rows()>0)

{
	return 'true';
}else{
	return  'false';
}
}
function get_alluser()
{
  $query = $this->db->get('user');
  //echo $this->db->last_query();
  if($query->num_rows()>0)
  {
  	return $query->result_array();

  }else{
  	return false;
  }
}
function get_msg_by_userid($userId)
{
	$query = $this->db->query("select * from chat_message where  user_id='$userId'");
   if($query->num_rows()>0)
   {
   	return $query->result_array();
   }
}

function get_all_msg($user_id,$admin)
{
	$this->db->select('*');
	$this->db->where(array('user_id'=>$user_id,'admin'=>$admin));
	
	$query = $this->db->get('chat_message');

  if($query->num_rows()>0)

{
	return $query->result_array();
}else{
	return false;
}
}
function send_img($user_id,$admin,$msg,$sender_name,$role)
{
	  if($role=='admin')
{
	$this->db->where(array('user_id'=>$user_id,'rep_id'=>'0'));
	$this->db->update('chat_session',array('rep_id'=>$admin));
}
	$query = $this->db->insert('chat_message',array('user_id'=>$user_id,'admin'=>$admin,'img_url'=>$msg,'sender_name'=>$sender_name));
	if($query)
	{ 
    
	       $last_id = $this->db->insert_id();
		   $this->db->where('id',$last_id);
	     	$query2 = $this->db->get("chat_message");
           if($query2->num_rows()>0)
           {
           	return $query2->row_array();
           }else
           {
           	return array('false');
           }
			}else{
		return array('false');
	}
}
function upload_profile_pic($user_id,$full_path)
{
	$this->db->where('id',$user_id);
	$this->db->update('user',array('profile_pic'=>$full_path));
}
}