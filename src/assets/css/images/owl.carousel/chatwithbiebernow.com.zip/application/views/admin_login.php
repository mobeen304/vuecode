<html>
<head>
 <link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700&subset=all" rel="stylesheet" type="text/css" />
<?php
//print_r($)
if(!empty($css))
{
   foreach ($css as $key => $value) {
    ?> 
 
     <link href="<?php  echo $value; ?>" rel="stylesheet" type="text/css" /> 
<?php
} }?>
<script async="" src="https://www.google-analytics.com/analytics.js"></script>
<?php

if(!empty($js))
{
   foreach ($js as $_jskey => $val) {
    ?>
    <script src="<?php  echo $val; ?>" type="text/javascript"></script>
    <?php
} }
?>
</head>
<body class=" login">
<input type="hidden" id="site_url" value="<?php echo site_url();  ?>">
        <!-- BEGIN LOGO -->
        <div class="logo">
            <a href="index.html">
                <img src="<?php echo base_url().'/assets/img/logo-big.png';  ?>" alt=""> </a>
        </div>
        <!-- END LOGO -->
        <!-- BEGIN LOGIN -->
        <div class="content">
            <!-- BEGIN LOGIN FORM -->
            <form class="login-form" action="<?php echo site_url().'/welcome/admin_loginCheck';  ?>" method="post" novalidate="novalidate" style="display: block;">
                <h3 class="form-title">Login to your account</h3>
                <div class="alert alert-danger display-hide">
                    <button class="close" data-close="alert"></button>
                    <span> Enter any username and password. </span>
                </div>
                <div class="form-group">
                    <!--ie8, ie9 does not support html5 placeholder, so we just show field title for that-->
                    <label class="control-label visible-ie8 visible-ie9">Username</label>
                    <div class="input-icon">
                        <i class="fa fa-user"></i>
                        <input class="form-control placeholder-no-fix" type="text"  autocomplete="off" placeholder="Username" name="username"> 
                        <span class="error_msg"><?php (isset($error))?$error:'';  ?></span></div>
                </div>
              <div class="form-group">
                    <label class="control-label visible-ie8 visible-ie9">Password</label>
                    <div class="input-icon">
                        <i class="fa fa-lock"></i>
                        <input class="form-control placeholder-no-fix" type="password" autocomplete="off" placeholder="Password" name="password"> </div>
                </div>
                  
              <div class="form-actions">
                    <label class="rememberme mt-checkbox mt-checkbox-outline">
                        <input type="checkbox" name="remember" value="1"> Remember me
                        <span></span>
                    </label>
                    <button type="submit" class="btn green pull-right" > Login </button>
                </div>
               
                
                
            </form>
            <!-- END LOGIN FORM -->
            <!-- BEGIN FORGOT PASSWORD FORM -->
          
            <!-- END FORGOT PASSWORD FORM -->
          
            <!-- END REGISTRATION FORM -->
        </div>
        <!-- END LOGIN -->
        <!--[if lt IE 9]>
<script src="../assets/global/plugins/respond.min.js"></script>
<script src="../assets/global/plugins/excanvas.min.js"></script> 
<script src="../assets/global/plugins/ie8.fix.min.js"></script> 
<![endif]-->
        <!-- BEGIN CORE PLUGINS -->





</body>

<script>
$(document).ready(function(){
var site_url = $('#site_url').val();
 $('#login-form').click(function(e){
e.preventDefault();
 if($('input[name="username"]').val()!='')
 {
$.ajax({
            url: site_url+"/welcome/startchat/"+$('input[name="username"]').val(),
            type:'POST',
            data:'check=bagznga',
            //async: false,
            success: function(data) {
               if(data!='false')
               {
                console.log(data);
                window.location.href = site_url+'/welcome/chat_view/'+data
               }
            }
        });
 }else{
    $('.error_msg').text('Please Enter Your Name');
 }

 });
 });

</script>
</html>