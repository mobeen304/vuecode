<html>
   <head>
      <link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700&subset=all" rel="stylesheet" type="text/css" />
      <?php
         //print_r($user_info);
         //print_r($user_msg);
         if(!empty($css))
         {
            foreach ($css as $key => $value) {
             ?> 
      <link href="<?php  echo $value; ?>" rel="stylesheet" type="text/css" />
      <?php
         } }?>
      <script async="" src="https://www.google-analytics.com/analytics.js"></script>
      <?php
         if(!empty($js))
         {
            foreach ($js as $_jskey => $val) {
             ?>
      <script src="<?php  echo $val; ?>" type="text/javascript"></script>
      <?php
         } }
         ?>
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>
   <body class="page-header-fixed page-sidebar-closed-hide-logo page-content-white wysihtml5-supported">
      <input type="hidden" id="site_url" value="<?php echo site_url();  ?>">
      <input type="hidden" id="admin" value="1">
      <input type="hidden" id="sender_name" value="<?php echo $user_info['0']['name'];  ?>">
      <input type="hidden" id="role" value="user">
      <input type="hidden" id="user_id" value="<?php echo $user_info['0']['id'];  ?>">
      <div class="portlet-title">
         <div class="caption">
            <div class="page-wrapper-row">
               <div class="page-wrapper-top">
                  <!-- BEGIN HEADER -->
                  <div class="ppage-header">
                     <!-- BEGIN HEADER TOP -->
                     <div class="page-header-top">
                        <div class="container">
                           <!-- BEGIN LOGO -->
                           <div class="page-logo">
                              <a href="index.html">
                              <img src="http://chatwithbiebernow.com/assets/img/user_profile.jpg" height="50" width="50" alt="logo" class="logo-default">
                              </a>
                           </div>
                           <!-- END LOGO -->
                           <!-- BEGIN RESPONSIVE MENU TOGGLER -->
                           <a href="javascript:;" class="menu-toggler"></a>
                           <!-- END RESPONSIVE MENU TOGGLER -->
                           <!-- BEGIN TOP NAVIGATION MENU -->
                           <div class="top-menu">
                              <ul class="nav navbar-nav pull-right">
                                 <!-- BEGIN NOTIFICATION DROPDOWN -->
                                 <!-- END TODO DROPDOWN -->
                                 <li class="droddown dropdown-separator">
                                    <span class="separator"></span>
                                 </li>
                                 <!-- BEGIN INBOX DROPDOWN -->
                                 <ul class="dropdown-menu">
                                    <li class="external">
                                       <h3>You have
                                          <strong>7 New</strong> Messages
                                       </h3>
                                       <a href="app_inbox.html">view all</a>
                                    </li>
                                    <li>
                                       <div class="slimScrollDiv" style="position: relative; overflow: hidden; width: auto; height: 275px;">
                                          <ul class="dropdown-menu-list scroller" style="height: 275px; overflow: hidden; width: auto;" data-handle-color="#637283" data-initialized="1">
                                          </ul>
                                          <div class="slimScrollBar" style="background: rgb(99, 114, 131); width: 7px; position: absolute; top: 0px; opacity: 0.4; display: block; border-radius: 7px; z-index: 99; right: 1px;"></div>
                                          <div class="slimScrollRail" style="width: 7px; height: 100%; position: absolute; top: 0px; display: none; border-radius: 7px; background: rgb(234, 234, 234); opacity: 0.2; z-index: 90; right: 1px;"></div>
                                       </div>
                                    </li>
                                 </ul>
                                 </li>
                                 <!-- END INBOX DROPDOWN -->
                                 <!-- BEGIN USER LOGIN DROPDOWN -->
                                 <li class="dropdown dropdown-user dropdown-dark">
                                    <a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-close-others="true" aria-expanded="false">
                                    <img alt="" class="img-circle" id="profile_pic" height="50" width="50" src="<?php echo $user_info['0']['profile_pic']  ?>">
                                    <span class="username username-hide-mobile"><?php echo $user_info['0']['name'] ?></span>
                                    </a>
                                    
                                 </li>
                                 <!-- END USER LOGIN DROPDOWN -->
                                 <!-- BEGIN QUICK SIDEBAR TOGGLER -->
                                 <!--  <li class="dropdown dropdown-extended quick-sidebar-toggler">
                                    <span class="sr-only">Toggle Quick Sidebar</span>
                                    <i class="icon-logout"></i>
                                    </li> -->
                                 <!-- END QUICK SIDEBAR TOGGLER -->
                              </ul>
                           </div>
                           <!-- END TOP NAVIGATION MENU -->
                        </div>
                     </div>
                     <!-- END HEADER TOP -->
                     <!-- BEGIN HEADER MENU -->
                  
                  </div>
                  <!-- END HEADER MENU -->
               </div>
               <!-- END HEADER -->
            </div>
         </div>
         <div calss="row">
            <div class="col-sm-4 "></div>
            <div class="col-sm-5 col-xs-12 chat" style=" outline: none;" tabindex="5001">
               <div class="portlet light ">
                  <div class="portlet-title">
                     <div class="caption font-red-sunglo">
                        <span class="caption-subject bold uppercase" style="
                           color: #333;
                           ">
                        If I dont reply Please msg me on Insta
                        </span>
                     </div>
                  </div>
               </div>
               <div class="col-inside-lg decor-default z-depth-2 portlet light bordered" style="padding: 12px 7px 15px;">
                  <div class="chat-body">
                     <div class="chat-header-title">Chat with User</div>
                     <div class="chatNotice" id="chatNotice">
                     </div>
                     <input type="hidden" id="user_id" value="<?php //echo //$user_info['0']['id'];  ?>">
                     <div class="portlet light "  style="padding: 12px 7px 15px;">
                        <div class="portlet-body">
                           <div class="scroller" style="height: 305px; overflow: hidden; width: auto;" data-always-visible="1" data-rail-visible1="0" data-handle-color="#D7DCE2" data-initialized="1">
                              <div id="scroll" class="general-item-list">
                                 <?php 
                                    if(isset($user_msg) && !empty($user_msg)){
                                    
                                    foreach ($user_msg as $key => $value) { ?>
                                 <div id="msg_<?php echo $value['id']; ?>" class="item">
                                    <div class="item-head">
                                       <div class="item-details">
                                          <img class="item-pic" src="<?php if($value['sender_name']!='admin'){ echo $user_info['0']['profile_pic'];}else{ echo 'http://chatwithbiebernow.com//assets/img/ad.png';}  ?>"  height="50" width="50">
                                          <a href="#" class="item-name primary-link"><?php echo $value['sender_name']; ?></a>
                                       </div> 
                                    </div>
                                    <?php if($value['img_url']!=''){
                                       ?>
                                    <div class="item-body">Img:<img data-holder-rendered="true" src="<?php echo $value['img_url']; ?>" style="width: 90px;height: 90px;"  alt="team14.jpg" class="img-responsive"><a href="<?php echo $value['img_url']; ?>" download="" class="" role="button">Click</a></div>
                                    <?php  }else{ ?>
                                    <div class="item-body">Message: <?php echo $value['msg']; ?> </div>
                                 </div>
                                 <?php  
                                    }?>
                                 <?php  
                                    } 
                                    }?>
                              </div>
                           </div>
                        </div>
                     </div>
                     <!--<form action="http://staging.myhopscotch.com/dashboard/chatsystem/upload.php" class="dropzone dropzone-file-area" id="my-dropzone" style="width: 500px; margin-top: 50px;" >
                        <h3 class="sbold">Drop files here or click to upload</h3>
                        </form>-->
                     <div class="main_div_box form-group form-md-line-input has-success form-md-floating-label">
                        <div class="answer-add input-group input-group-lg">
                           <input class="form-control input-lg edited" placeholder="Type your message here..." id="messageBox" >
                           <br>
                           <!--<label for="form_control_1">Type your message here...onkeydown="handleKey(event);"</label>-->
                           <!--<span class="answer-btn answer-btn-1"></span>-->
                           <!--<span class="answer-btn answer-btn-2" onclick="sendMessage();" ></span>-->
                           <input type="hidden" id="reciever" value="" name="receiver">
                        </div>
                        <span class="input-group-btn btn-right">
                        <button class="btn green-haze" type="button" id="sendMessage">Send</button>
                        </span>
                        <!--  <div class="end_chat">
                           <a href="<?php echo site_url().'/welcome/logout/' ?>" class="btn red-haze" id="end_btn" title="End Chat"> 
                           End Chat
                           <i class="fa fa-sign-out"></i>
                           </a>
                           </div> -->
                        <div id="myDropzone3" class="upload_img btn green dz-clickable" style="display: none">
                           Click here to Upload Files
                           <i class="fa fa-cloud-upload" aria-hidden="true"></i>
                        </div>
                        <div class="clearfix"></div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      </div>
      </div>
   </body>
</html>