<html>
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <head>
      <link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700&subset=all" rel="stylesheet" type="text/css" />
      <?php
         //print_r($user_info);
         //print_r($user_msg);
         if(!empty($css))
         {
            foreach ($css as $key => $value) {
             ?> 
      <link href="<?php  echo $value; ?>" rel="stylesheet" type="text/css" />
      <?php
         } }?>
      <script async="" src="https://www.google-analytics.com/analytics.js"></script>
      <?php
         if(!empty($js))
         {
            foreach ($js as $_jskey => $val) {
             ?>
      <script src="<?php  echo $val; ?>" type="text/javascript"></script>
      <?php
         } }
         ?>
   </head>
   <body class="page-header-fixed page-sidebar-closed-hide-logo page-content-white wysihtml5-supported">
      <input type="hidden" id="site_url" value="<?php echo site_url();  ?>">
      <input type="hidden" id="admin" value="1">
      <input type="hidden" id="user_id" value="<?php echo $userId;  ?>">
      <input type="hidden" id="sender_name" value="<?php echo 'admin';  ?>">
      <input type="hidden" id="role" value="admin">
      <div class="portlet-title">
      <div class="caption">
         <div class="page-wrapper-row">
            <div class="page-wrapper-top">
               <!-- BEGIN HEADER -->
               <div class="ppage-header">
                  <!-- BEGIN HEADER TOP -->
                  <div class="page-header-top">
                     <div class="container">
                        <!-- BEGIN LOGO -->
                        <div class="page-logo">
                           <a href="index.html">
                           <img src="<?php echo base_url().'/assets/img/logo-big.png';  ?>" alt="logo" class="logo-default">
                           </a>
                        </div>
                        <!-- END LOGO -->
                        <!-- BEGIN RESPONSIVE MENU TOGGLER -->
                        <a href="javascript:;" class="menu-toggler"></a>
                        <!-- END RESPONSIVE MENU TOGGLER -->
                        <!-- BEGIN TOP NAVIGATION MENU -->
                        <div class="top-menu">
                           <ul class="nav navbar-nav pull-right">
                              <!-- BEGIN NOTIFICATION DROPDOWN -->
                              <!-- END TODO DROPDOWN -->
                              <li class="droddown dropdown-separator">
                                 <span class="separator"></span>
                              </li>
                              <!-- BEGIN INBOX DROPDOWN -->
                               
                              </li>
                              <!-- END INBOX DROPDOWN -->
                              <!-- BEGIN USER LOGIN DROPDOWN -->
                              <li class="dropdown dropdown-user dropdown-dark">
                                 <a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-close-others="true" aria-expanded="false">
                                 <img alt="" class="img-circle" height="30" width="30" src="<?php echo base_url().'/assets/img/user_profile.jpg';  ?>">
                                 <span class="username username-hide-mobile"><?php //echo //$user_info['0']['name'] ?></span>
                                 </a>
                                 <ul class="dropdown-menu dropdown-menu-default">
                                    <li>
                                       <a href="page_user_profile_1.html">
                                       <i class="icon-user"></i> My Profile </a>
                                    </li>
                                    <li>
                                       <a href="app_calendar.html">
                                       <i class="icon-calendar"></i> My Calendar </a>
                                    </li>
                                    <li>
                                       <a href="app_inbox.html">
                                       <i class="icon-envelope-open"></i> My Inbox
                                       <span class="badge badge-danger"> 3 </span>
                                       </a>
                                    </li>
                                    <li>
                                       <a href="app_todo_2.html">
                                       <i class="icon-rocket"></i> My Tasks
                                       <span class="badge badge-success"> 7 </span>
                                       </a>
                                    </li>
                                    <li class="divider"> </li>
                                    <li>
                                       <a href="page_user_lock_1.html">
                                       <i class="icon-lock"></i> Lock Screen </a>
                                    </li>
                                    <li>
                                       <a href="page_user_login_1.html">
                                       <img id="detail-icon-img" src="<?php echo base_url().'/assets/img/Exit-16.png';  ?>" alt="arrow, enter, forward, login, move, next, right icon" width="16" height="16"> </a>
                                    </li>
                                 </ul>
                              </li>
                              <li class="dropdown dropdown-quick-sidebar-toggler">
                                 <a href="javascript:;" class="dropdown-toggle">
                                 <img id="detail-icon-img" src="<?php echo base_url().'/assets/img/Enter-16.png';  ?>" alt="arrow, enter, forward, login, move, next, right icon" width="16" height="16">
                                 </a>
                              </li>
                              <!-- END USER LOGIN DROPDOWN -->
                              <!-- BEGIN QUICK SIDEBAR TOGGLER -->
                              <!--  <li class="dropdown dropdown-extended quick-sidebar-toggler">
                                 <span class="sr-only">Toggle Quick Sidebar</span>
                                 <i class="icon-logout"></i>
                                 </li> -->
                              <!-- END QUICK SIDEBAR TOGGLER -->
                           </ul>
                        </div>
                        <!-- END TOP NAVIGATION MENU -->
                     </div>
                  </div>
                  <!-- END HEADER TOP -->
                  <!-- BEGIN HEADER MENU -->
                  <div class="page-header-menu">
                     <div class="container">
                        <!-- END MEGA MENU -->
                     </div>
                  </div>
                  <!-- END HEADER MENU -->
               </div>
               <!-- END HEADER -->
            </div>
         </div>
         <div calss="row">
            <div class="col-sm-4 "></div>
            <div class="col-sm-5 col-xs-12 chat" style=" outline: none;" tabindex="5001">
               <div class="col-inside-lg decor-default z-depth-2 portlet light bordered">
                  <div class="chat-body">
                     <div class="chat-header-title">Chat with User</div>
                     <div class="chatNotice" id="chatNotice">
                     </div>
                     <input type="hidden" id="user_id" value="<?php //echo //$user_info['0']['id'];  ?>">
                     <div class="portlet light " style="padding: 12px 7px 15px;">
                        <div class="portlet-body">
                           <div class="scroller" style="height: 305px; overflow: hidden; width: auto;" data-always-visible="1" data-rail-visible1="0" data-handle-color="#D7DCE2" data-initialized="1">
                              <div id="scroll" class="general-item-list">
                                 <?php 
                                    if(isset($user_msg) && !empty($user_msg)){
                                    
                                    foreach ($user_msg as $key => $value) { ?>
                                 <div id="msg_<?php echo $value['id']; ?>" class="item">
                                    <div class="item-head">
                                       <div class="item-details">
                                          <img class="item-pic" src="<?php echo base_url().'/assets/img/ad.png';  ?>">
                                          <a href="#" class="item-name primary-link"><?php echo $value['sender_name']; ?></a>
                                       </div>
                                    </div>
                                    <?php if($value['img_url']!=''){
                                       ?>
                                    <div class="item-body">Img:<img data-holder-rendered="true" src="<?php echo $value['img_url']; ?>" style="width: 90px;height: 90px;" "="" alt="team14.jpg" class="img-responsive"><a href="<?php echo $value['img_url']; ?>" download="" class="" role="button">Image</a></div>
                                    <?php  }else{ ?>
                                    <div class="item-body">Message: <?php echo $value['msg']; ?> </div>
                                 </div>
                                 <?php  
                                    }
                                    } 
                                    }?>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="main_div_box form-group form-md-line-input has-success form-md-floating-label">
                        <div class="answer-add input-group input-group-lg">
                           <input class="form-control input-lg edited" placeholder="Type your message here..." id="messageBox" >
                           <!--<label for="form_control_1">Type your message here...onkeydown="handleKey(event);"</label>-->
                           <!--<span class="answer-btn answer-btn-1"></span>-->
                           
                           <!--<span class="answer-btn answer-btn-2" onclick="sendMessage();" ></span>-->
                           <input type="hidden" id="reciever" value="" name="receiver">
                        </div><br><span class="input-group-btn btn-right">
                           <button class="btn green-haze" type="button" id="sendMessage">Send</button>
                           </span>
                        <!--<div class="end_chat">
                           <a href="javascript:void(0)" class="btn red-haze" id="end_btn" title="End Chat"> 
                           End Chat
                           <i class="fa fa-sign-out"></i>
                           </a>
                        </div>-->
                        <div class="clearfix"></div>
                     </div>
                  </div>
               </div>
            </div>
            
         </div>
      </div>
      <a href="javascript:;" class="page-quick-sidebar-toggler __web-inspector-hide-shortcut__">
      <img id="detail-icon-img" src="<?php echo base_url().'/assets/img/Exit-16.png';  ?>" alt="arrow, enter, forward, login, move, next, right icon" width="16" height="16">
      </a>
      <div class="page-quick-sidebar-wrapper" data-close-on-body-click="false">
         <div class="page-quick-sidebar">
            <ul class="nav nav-tabs">
               <li class="active">
                  <a href="javascript:;" data-target="#quick_sidebar_tab_1" data-toggle="tab">Users
                  <span class="badge badge-danger">2</span>
                  </a>
               </li>
            </ul>
            <div class="tab-content">
               <div class="tab-pane page-quick-sidebar-chat active page-quick-sidebar-content-item-shown" id="quick_sidebar_tab_1">
                  <div class="page-quick-sidebar-list" style="position: relative; overflow: hidden; width: auto; height: 538px;">
                     <div class="page-quick-sidebar-chat-users" data-rail-color="#ddd" data-wrapper-class="page-quick-sidebar-list" data-height="538" data-initialized="1" style="overflow: hidden; width: auto; height: 538px;">
                        <h3 class="list-heading">Staff</h3>
                     </div>
                     <div class="slimScrollBar" style="background: rgb(187, 187, 187); width: 7px; position: absolute; top: 0px; opacity: 0.4; display: block; border-radius: 7px; z-index: 99; right: 1px; height: 531.551px;"></div>
                     <div class="slimScrollRail" style="width: 7px; height: 100%; position: absolute; top: 0px; display: none; border-radius: 7px; background: rgb(221, 221, 221); opacity: 0.2; z-index: 90; right: 1px;"></div>
                  </div>
                  <div class="page-quick-sidebar-item">
                     <div class="page-quick-sidebar-chat-user">
                        <div class="page-quick-sidebar-nav">
                           <a href="javascript:;" class="page-quick-sidebar-back-to-list">
                           <i class="icon-arrow-left"></i>Back</a>
                        </div>
                        <div class="slimScrollDiv" style="position: relative; overflow: hidden; width: auto; height: 533px;">
                           <div class="page-quick-sidebar-chat-user-messages" data-height="433" data-initialized="1" style="overflow: hidden; width: auto; height: 533px;">
                           	<div class="mt-comments">
                           		<?php foreach($user_info as $value){
			                     ?> 
                                                <div class="mt-comment">
                                                    <div class="mt-comment-img">
                                                        <img style="width:50px" class="media-object" src="<?php echo base_url().'/assets/img/ad.png';  ?>" alt="..."></div>
                                                    <div class="mt-comment-body">
                                                        <div class="mt-comment-info">
                                                            <span class="mt-comment-author"> <a href="<?php echo site_url().'/welcome/adminChat_view/'.$value['id'] ?>"><?php echo $value['name'];  ?></a></span>
                                                            
                                                        </div>
                                                         
                                                    </div>
                                                </div>
                                                
                                                
                                                <?php
			                     }
			                     ?> 
                                            </div>
                            
                           </div>
                        </div>
                     </div>
                     </ul>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </body>
</html>