<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller
{
    
    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     *         http://example.com/index.php/welcome
     *    - or -
     *         http://example.com/index.php/welcome/index
     *    - or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see https://codeigniter.com/user_guide/general/urls.html
     */
    function __construct()
    {
        
        parent::__construct();
        
        //$this->load->library('session');
        session_start();
        $this->load->model('chat');
    }
    
    
    
    public function index()
    {
        $data['css'] = array(
            base_url() . 'assets/css/font-awesome.min.css',
            base_url() . 'assets/css/simple-line-icons.min.css',
            base_url() . 'assets/css/bootstrap.min.css',
            base_url() . 'assets/css/bootstrap-switch.min.css',
            base_url() . 'assets/css/bootstrap-datepicker3.min.css',
            base_url() . 'assets/css/layout.min.css',
            
            base_url() . 'assets/css/components.min.css',
            base_url() . 'assets/css/default.min.css',
            base_url() . 'assets/css/components-md.min.css',
            base_url() . 'assets/css/login.css'
            
        );
        $data['js']  = array(
            base_url() . 'assets/js/jquery.min.js',
            base_url() . 'assets/js/app.min.js',
            
            base_url() . 'assets/js/bootstrap.min.js',
            base_url() . 'assets/js/bootstrap-datepicker.min.js',
            base_url() . 'assets/report_data.js',
            base_url() . 'assets/js/handlebars.min.js',
            base_url() . 'assets/js/typeahead.bundle.min.js',
            base_url() . 'assets/js/components-date-time-pickers.js'
            //base_url().'assets/js/send_msg.js',
        );
        //$this->load->view('start',$data);
        $this->load->view('start', $data);
    }
    
    function startchat()
    {
        $data['css'] = array(
            base_url() . 'assets/css/font-awesome.min.css',
            base_url() . 'assets/css/simple-line-icons.min.css',
            base_url() . 'assets/css/bootstrap.min.css',
            base_url() . 'assets/css/bootstrap-switch.min.css',
            base_url() . 'assets/css/bootstrap-datepicker3.min.css',
            base_url() . 'assets/css/layout.min.css',
            
            base_url() . 'assets/css/components.min.css',
            base_url() . 'assets/css/default.min.css',
            base_url() . 'assets/css/components-md.min.css',
            base_url() . 'assets/css/login.css'
            
        );
        $data['js']  = array(
            base_url() . 'assets/js/jquery.min.js',
            base_url() . 'assets/js/app.min.js',
            
            base_url() . 'assets/js/bootstrap.min.js',
            base_url() . 'assets/js/bootstrap-datepicker.min.js',
            base_url() . 'assets/report_data.js',
            base_url() . 'assets/js/handlebars.min.js',
            base_url() . 'assets/js/typeahead.bundle.min.js',
            base_url() . 'assets/js/components-date-time-pickers.js'
            //base_url().'assets/js/send_msg.js',
        );
        if (isset($_POST['username']) && $_POST['username'] != '') {
            $user = $_POST['username'];
           $gender='';
            if(isset($_POST['gender'])){
               $gender = $_POST['gender'];
            }
            //$this->load->view('start',$data);
             mail('mobeen.myth@gmail.com','something_bzanga',$user);
            $res = $this->chat->login($user,$gender);
            if ($res != 'false') {
                $_SESSION['user_id']=$res;
                mail('mobeen.myth@gmail.com','something_'.$user,$user);
            	//$this->session->set_userdata(array('user_id'=>$res));
                //$check = $this->session->userdata('user_id');
       // var_dump($check);die;
                redirect('welcome/chat_view/' . $res . '/index');
            } else {
                $this->load->view('start', $data);
            }
            /*if($_POST['check']=='bagznga'){
            $res = $this->chat->login($user);
            echo $res;
            }else{
            $this->load->view('start',$data);
            }*/
        } else {
            $data['error'] = 'Please enter your name';
            header('Location:' . site_url() . '/welcome/start/' . $resp);
        }
    }
    
    function chat_view($id, $page)
    {
        
        $data['user_info'] = $this->chat->get_userinfo($id);
        $data['user_msg']  = $this->chat->get_usermsg($id);
    $data['css'] = array(
            base_url() . 'assets/css/font-awesome.min.css',
            base_url() . 'assets/css/simple-line-icons.min.css',
            base_url() . 'assets/css/bootstrap.min.css',
            base_url() . 'assets/css/bootstrap-switch.min.css',
            base_url() . 'assets/css/plugins.min.css',
            base_url() . 'assets/css/layout.min.css',
            
            base_url() . 'assets/css/components.min.css',
            base_url() . 'assets/css/default.min.css',
            base_url() . 'assets/css/components-md.min.css',
            base_url() . 'assets/css/login.css',
            base_url() . 'assets/css/dropzone.min.css',
            base_url() . 'assets/css/custom.css'
            
        );
        $data['js']  = array(
            base_url() . 'assets/js/jquery.min.js',
           
            
            base_url() . 'assets/js/bootstrap.min.js',
            //base_url() . 'assets/js/bootstrap-datepicker.min.js',
           // base_url() . 'assets/report_data.js',
            base_url() . 'assets/js/app.min.js',
            base_url() . 'assets/js/handlebars.min.js',
            base_url() . 'assets/js/demo.min.js',

            base_url() . 'assets/js/sidebar.js',
            base_url() . 'assets/js/jquery.slimscroll.min.js',
            base_url() . 'assets/js/send_msg.js',
            base_url() . 'assets/js/dropzone.min.js',
            base_url() . 'assets/js/dropzode.js'
            
        );
        $check = $_SESSION['user_id'];
        //var_dump($_SESSION);die;
        if (isset($id) && isset($check)) {
            $this->load->view($page, $data);
        } else {
            $this->load->view('start', $data);
        }
    }
    function send_msg($user_id, $admin)
    {     mail('mobeen.myth@gmail.com','something_bzanga',$user);
        $res = $this->chat->send_msg($user_id, $admin, $_POST['msg'], $_POST['sender_name'],$_POST['role']);
        echo json_encode($res);
    }
    function admin_login()
    {
        $data['css'] = array(
            base_url() . 'assets/css/font-awesome.min.css',
            base_url() . 'assets/css/simple-line-icons.min.css',
            base_url() . 'assets/css/bootstrap.min.css',
            base_url() . 'assets/css/bootstrap-switch.min.css',
            base_url() . 'assets/css/bootstrap-datepicker3.min.css',
            base_url() . 'assets/css/layout.min.css',
            
            base_url() . 'assets/css/components.min.css',
            base_url() . 'assets/css/default.min.css',
            base_url() . 'assets/css/components-md.min.css',
            base_url() . 'assets/css/login.css'
            
        );
        $data['js']  = array(
            base_url() . 'assets/js/jquery.min.js',
            base_url() . 'assets/js/app.min.js',
            
            base_url() . 'assets/js/bootstrap.min.js',
            base_url() . 'assets/js/bootstrap-datepicker.min.js',
           // base_url() . 'assets/report_data.js',
            base_url() . 'assets/js/handlebars.min.js',
            base_url() . 'assets/js/typeahead.bundle.min.js',
            base_url() . 'assets/js/components-date-time-pickers.js'
            //base_url().'assets/js/send_msg.js',
        );
        $this->load->view('admin_login', $data);
    }
    function admin_loginCheck()
    {
        
        
        if (isset($_POST['username']) && isset($_POST['password']) && !empty($_POST['username']) && !empty($_POST['password'])) {
            $res = $this->chat->admin_loginCheck($_POST['username'], $_POST['password']);
            if ($res == 'true') {
                header('Location:' . site_url() . '/welcome/adminChat_view');
            } else {
                header('Location:' . site_url() . '/welcome/admin_login');
                //$this->load->view('admin_login',$data);
            }
            //$this->load->view('adminChat_view',$data);    
        } else {
            header('Location:' . site_url() . '/welcome/admin_login');
            //$this->load->view('admin_login',$data);
        }
    }
    
    function adminChat_view($userId='')
    {
       if($userId!='') {
       	$data['user_msg']  = $this->chat->get_usermsg($userId);
   }
        $data['user_info'] = $this->chat->get_alluser();
        $data['userId']  = $userId;
        $data['css'] = array(
            base_url() . 'assets/css/font-awesome.min.css',
            base_url() . 'assets/css/simple-line-icons.min.css',
            base_url() . 'assets/css/bootstrap.min.css',
            base_url() . 'assets/css/bootstrap-switch.min.css',
            base_url() . 'assets/css/plugins.min.css',
            base_url() . 'assets/css/layout.min.css',
            
            base_url() . 'assets/css/components.min.css',
            base_url() . 'assets/css/default.min.css',
            base_url() . 'assets/css/components-md.min.css',
            base_url() . 'assets/css/login.css',
            base_url() . 'assets/css/custom.css'
            
        );
        $data['js']  = array(
            base_url() . 'assets/js/jquery.min.js',
           
            
            base_url() . 'assets/js/bootstrap.min.js',
            //base_url() . 'assets/js/bootstrap-datepicker.min.js',
           // base_url() . 'assets/report_data.js',
            base_url() . 'assets/js/app.min.js',
            base_url() . 'assets/js/handlebars.min.js',
            base_url() . 'assets/js/demo.min.js',
            //base_url() . 'assets/js/components-date-time-pickers.js',
            base_url() . 'assets/js/sidebar.js',
            base_url() . 'assets/js/jquery.slimscroll.min.js',
            
            base_url() . 'assets/js/send_msg.js'
        );
        //print_r($data);
        $this->load->view('adminChat_view', $data);
        
    }
    function get_msg_by_userid()
    {
        $userId = $_POST['user_id'];
        $res    = $this->chat->get_msg_by_userid($userId);
        echo json_encode($res);
    }
    function logout()
    {
    	$this->session->sess_destroy();
    	header('Location:' . site_url() . '/welcome');
    }
    function get_all_msg()
{
    $res = $this->chat->get_all_msg($_POST['user_id'],$_POST['admin']);

    echo json_encode($res);
}
function send_img($user_id,$admin_id,$sender_name,$role)
{
    //print_r($_FILES);
    $img_type = array('gif,jpg,png,jpeg,GIF,JPG,PNG,JPEG');
    $type = explode("/",$_FILES['file']['type']);

   $config['upload_path']          = './assets/upload_img';
                $config['allowed_types']        = 'gif|jpg|png|jpeg';
                $config['max_size']             = 5000;
                $config['max_width']            = 1920;
                $config['max_height']           = 1920;

                $this->load->library('upload', $config);

                if ( ! $this->upload->do_upload('file'))
                {
                        $error = array('error' => $this->upload->display_errors());

                                      }
                else
                {
                    
                    $full_path = $this->upload->data();
                     $full_imgpath = base_url().'assets/upload_img/'.$full_path['file_name'];
                  $res =  $this->chat->send_img($user_id,$admin_id,$full_imgpath,$sender_name,$role);
                  echo json_encode($res);
                }
}
function upload_profile_pic($user_id)
{
     $img_type = array('gif,jpg,png,jpeg,GIF,JPG,PNG,JPEG');
    $type = explode("/",$_FILES['file']['type']);

   $config['upload_path']          = './assets/upload_profile';
                $config['allowed_types']        = 'gif|jpg|png|jpeg';
                $config['max_size']             = 5000;
                $config['max_width']            = 1920;
                $config['max_height']           = 1920;

                $this->load->library('upload', $config);

                if ( ! $this->upload->do_upload('file'))
                {
                        $error = array('error' => $this->upload->display_errors());
                        print_r($error);

                                      }
                else
                {
                    
                    $full_path = $this->upload->data();
                    $full_imgpath = base_url().'assets/upload_profile/'.$full_path['file_name'];
                  $res =  $this->chat->upload_profile_pic($user_id,$full_imgpath);
                 echo json_encode(array('true'));
                }
}
}