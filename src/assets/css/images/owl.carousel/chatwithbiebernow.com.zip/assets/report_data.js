$(document).ready(function (){
	
 $('#search_rec').typeahead({
    hint: true,
    highlight: true,
    minLength: 3,
    limit: 8
}, {
    source: function (q, cb) {
        return $.ajax({
            dataType: 'json',
            type: 'get',
            url: $('#site_url').val()+'/main_con/get_rec_by_repId/' + q,
            chache: false,
            success: function (data) {
                var result = [];
                console.log(data);
                $.each(data, function (index, val) {
                    result.push({
                        value: val
                    });
                });
                cb(data);
            }
        });
    }
});

	$('#form_sample_21').submit(function(event){
  
   $.ajax({
         url:'http://localhost/hos/index.php/main_con/save_values',
         type:'POST',
         data:$( this ).serializeArray(),
         success:function(data)
         {
         
         }
   });

	});
})

 