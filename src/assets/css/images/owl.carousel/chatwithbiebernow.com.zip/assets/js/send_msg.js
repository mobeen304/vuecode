$(document).ready(function () { 
setTimeout("get_all_msg();", 5000);
  var site_url = $('#site_url').val();



$('.scroller').slimScroll({});

 

	$('#sendMessage').click(function(){
      current_user_id = $('#user_id').val();
   msg = $('#messageBox').val();
    $('#messageBox').val('');
  $.ajax({
      url: site_url+"/welcome/send_msg/"+current_user_id+'/'+$('#admin').val(),
      type:'POST',
      data:'msg='+msg+'&sender_name='+$('#sender_name').val()+'&role='+$('#role').val(),
      dataType:'json',
      //async: false,
      success: function(data) {
              if(data!='false')
              {
 
                  
                    displayMessage('<div id="msg_'+data.id+'" class="item"><div class="item-head"> <div class="item-details"><img class="item-pic" src="http://chatwithbiebernow.com/assets/img/user_profile.jpg"><a href="#" class="item-name primary-link">'+data.sender_name+'</a> </div></div><div class="item-body">Message: '+data.msg+' </div</div>');
           
              }
      }
    });
	
});

	$('#messageBox').keypress(function (e) {

 var key = e.which;
 if(key == 13)  // the enter key code
  {
      current_user_id = $('#user_id').val();
   msg = $('#messageBox').val();
    $('#messageBox').val('');
	$.ajax({
			url: site_url+"/welcome/send_msg/"+current_user_id+'/'+$('#admin').val(),
			type:'POST',
			data:'msg='+msg+'&sender_name='+$('#sender_name').val()+'&role='+$('#role').val(),
			dataType:'json',
			//async: false,
			success: function(data) {
              if(data!='false')
              {
 
                  
                  	displayMessage('<div id="msg_'+data.id+'" class="item"><div class="item-head"> <div class="item-details"><img class="item-pic" src="'+$('#profile_pic').attr('src')+'"><a href="#" class="item-name primary-link">'+data.sender_name+'</a> </div></div><div class="item-body">Message: '+data.msg+' </div</div>');
           
              }
			}
		}); 
  }
}); 
$('.user_chat').click(function(){
   $.ajax({
     url:site_url+'/welcome/get_msg_by_userid',
     type:'POST',
     data:'user_id='+$(this).attr('id'),
     dataType:'json',
     success:function(data)
     {
  console.log(data);
     }
   });
   
});
});

// displays a message
function displayMessage(message, mes_type)
{

    // get the scroll object
    console.log(message)
    $('#scroll').append(message);
    /*var msgcontainer = document.getElementById("scroll");
    var oScroll = document.getElementById("scroll").parentElement;
    // display the message  
    if (mes_type == '') {
        msgcontainer.innerHTML += message;
        var scrollDown = (oScroll.scrollHeight - oScroll.scrollTop <=
                oScroll.offsetHeight);
        // scroll down the scrollbar
        // check if the scroll is down
        //oScroll.scrollTop = scrollDown ? oScroll.scrollHeight : oScroll.scrollTop;
        oScroll.scrollTop = oScroll.scrollHeight;
    }
    else {
        //msgcontainer.innerHTML += message;
        msgcontainer.innerHTML = message + msgcontainer.innerHTML;
    }*/
}

function get_all_msg()
{

  if (typeof get_all_mesg !== 'undefined') {
    clearTimeout(get_all_mesg);
  }
   $.ajax({
    url:$('#site_url').val()+'/welcome/get_all_msg',
    type:'POST',
    data:'user_id='+$('#user_id').val()+'&admin='+$('#admin').val(),
    dataType:'json',
    success:function(data)
    {
       if(data!=false){
        $.each(data,function(key,data){
          //console.log(('#scroll div#msg_'+data.id).length);
          //console.log(('#scroll div#msg_'+data.id));
  if($('div#msg_'+data.id).length==0){
   // console.log(('#scroll div#msg_'+data.id));
if(data.sender_name=='admin'){
    displayMessage('<div id="msg_'+data.id+'" class="item"><div class="item-head"> <div class="item-details"><img class="item-pic" src="http://chatwithbiebernow.com//assets/img/ad.png"><a href="#" class="item-name primary-link">'+data.sender_name+'</a> </div></div><div class="item-body">Message: '+data.msg+' </div</div>');
}else{
displayMessage('<div id="msg_'+data.id+'" class="item"><div class="item-head"> <div class="item-details"><img class="item-pic" src="http://chatwithbiebernow.com/assets/img/user_profile.jpg"><a href="#" class="item-name primary-link">'+data.sender_name+'</a> </div></div><div class="item-body">Message: '+data.msg+' </div</div>');
}
}
})
}
    }
  });
   get_all_mesg = setTimeout("get_all_msg();", 5000);
}