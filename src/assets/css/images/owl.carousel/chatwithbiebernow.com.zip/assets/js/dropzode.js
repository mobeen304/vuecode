var FormDropzone = function () {


    return {
        //main function to initiate the module
        init: function () {  

            Dropzone.options.myDropzone = {
                dictDefaultMessage: "",
                init: function() {
                    this.on("addedfile", function(file) {
                        // Create the remove button
                         console.log('fff');
                        var removeButton = Dropzone.createElement("<a href='javascript:;'' class='btn red btn-sm btn-block'>Remove</a>");
                        
                        // Capture the Dropzone instance as closure.
                        var _this = this;

                        // Listen to the click event
                        removeButton.addEventListener("click", function(e) {
                          // Make sure the button click doesn't submit the form:
                          e.preventDefault();
                          e.stopPropagation();

                          // Remove the file preview.
                          _this.removeFile(file);
                          // If you want to the delete the file on the server as well,
                          // you can do the AJAX request here.
                        });

                        // Add the button to the file preview element.
                        file.previewElement.appendChild(removeButton);
                       // var newTextBoxDiv = $(document.createElement('div')).attr("class", "answer right");
                       // newTextBoxDiv.after().html(file.previewElement);
                       // newTextBoxDiv.appendTo("#scroll");
                       // $("#scroll").append(file.previewElement); 
                        //console.log(file.previewElement); 
                    });       
                    this.on("complete", function(file) {
                      console.log(file.name);  
             this.removeFile(file);
          });
          this.on("success", function(file, response) {  
          console.log(response);
                       var response =  jQuery.parseJSON(response); 
               if(response.file_type.indexOf('image') != -1){
              var image_name =response.file_url; 
             }else{
              image_name ="https://placehold.it/250x178?text="+response.file_type; 
             }
                        toastr.info("File Uploaded successfully");
                         //alert(response);
                         var newTextBoxDiv = $(document.createElement('div')).attr("class", "col-sm-3 col-md-3");
                         var thumbnailDiv = $(document.createElement('div')).attr("class", "thumbnail");
                         var captionDiv = $(document.createElement('div')).attr("class", "caption");
                         newTextBoxDiv.attr("id","row-"+response.img_id);
                         thumbnailDiv.append('<img data-holder-rendered="true" src="'+image_name+'" style="width: 200px;height: 160px;" "="" alt="team14.jpg" class="img-responsive">');
                         captionDiv.append('<h3 class="file_name">'+response.file_name+'</h3><p>'+response.file_type+'</p><p><a href="'+response.file_url+'" class="btn btn-primary" role="button" data-lightbox="example-set"><i class="fa fa-eye"></i></a> <a href="'+response.file_url+'" download="" class="btn btn-warning" role="button"><i class="fa fa-download"></i></a> <a href="javascript:;" class="btn btn-danger" onclick="delete_file('+response.img_id+');" role="button"><i class="fa fa-trash"></i></a></p>');
                thumbnailDiv.append(captionDiv);
                         newTextBoxDiv.append(thumbnailDiv);
                        $(".file-upload-row").append(newTextBoxDiv);
                        if(typeof lightbox !== 'undefined' && lightbox.hasOwnProperty("album")){
                  thumbnailDiv.find("a").each(function(){
                   if(typeof jQuery(this).data('lightbox') !== 'undefined'){
                    jQuery(this).on('click', function(event) {
                     lightbox.start($(this));
                     return false;
                       });
                   }
                  });
                 }
                });
                this.on("error", function(file, response) {
                         toastr.error(response);
                });
             
                }            
            }
        }
    };
}();


var FormDropzone3 = function () {
    return {
        //main function to initiate the module
        init: function () {  

            Dropzone.options.myDropzone3 = {
                dictDefaultMessage: "",
                init: function() {
                    this.on("addedfile", function(file) {
                      
                    });       
                    this.on("complete", function(file) {
                      console.log(file.name);  
             this.removeFile(file);
          });
          this.on("success", function(file, response) { 
             
               var response =  jQuery.parseJSON(response); 
            
              var image_name =response.img_url; 
            console.log(response.img_url);
                    $('#scroll').append('<div id="msg_'+response.id+'" class="item"><div class="item-head"> <div class="item-details"><img class="item-pic" src="http://[::1]/new_pr//assets/img/ad.png"><a href="#" class="item-name primary-link">'+response.sender_name+'</a> </div></div><div class="item-body">Img:<img data-holder-rendered="true" src="'+image_name+'" style="width: 90px;height: 90px;" "="" alt="team14.jpg" class="img-responsive"><a href="'+image_name+'" download class="" role="button">'+file.name+'</a>  </div</div>');
               
                           //alert(response);
                         //console.log(response.status); 
                });
                this.on("error", function(file, response) {
                         console.log(response);
                });
             
                }            
            }
        }
    };
}();

var FormDropzone2 = function () {
    return {
        //main function to initiate the module
        init: function () {  

            Dropzone.options.myDropzone2 = {
                dictDefaultMessage: "",
                init: function() {
                          this.on("addedfile", function(file) {
                        // Create the remove button
                       /* var removeButton = Dropzone.createElement("<a href='javascript:;'' style='width:122px'  class='btn red btn-sm btn-block'>Remove</a>");
                        
                        // Capture the Dropzone instance as closure.
                        var _this = this;

                        // Listen to the click event
                        removeButton.addEventListener("click", function(e) {
                          // Make sure the button click doesn't submit the form:
                          e.preventDefault();
                          e.stopPropagation();

                          // Remove the file preview.
                          _this.removeFile(file);
                          // If you want to the delete the file on the server as well,
                          // you can do the AJAX request here.
                        });

                        // Add the button to the file preview element.
                        file.previewElement.appendChild(removeButton);
                        var newTextBoxDiv = $(document.createElement('div')).attr("class", "answer right");
                        newTextBoxDiv.after().html(file.previewElement);
                        newTextBoxDiv.appendTo("#scroll");
                        $("#scroll").append(file.previewElement); 
                        //console.log(file.previewElement); */
                    });     
                    this.on("complete", function(file) {
                      console.log(file.name);  
             this.removeFile(file);
          });
          this.on("success", function(file, response) { 
             
               var response =  jQuery.parseJSON(response); 
            
              var image_name =response.img_url; 
            console.log(response.img_url);
                    $('#scroll').append('<div id="msg_'+response.id+'" class="item"><div class="item-head"> <div class="item-details"><img class="item-pic" src="http://[::1]/new_pr//assets/img/ad.png"><a href="#" class="item-name primary-link">'+response.sender_name+'</a> </div></div><div class="item-body">Img:<img data-holder-rendered="true" src="'+image_name+'" style="width: 200px;height: 160px;" "="" alt="team14.jpg" class="img-responsive"><a href="'+image_name+'" download class="btn btn-warning" role="button">'+file.name+'</a>  </div</div>');
               
                           //alert(response);
                         //console.log(response.status); 
                });
                this.on("error", function(file, response) {
                         console.log(response);
                });
             
                }            
            }
        }
    };
}();
jQuery(document).ready(function() {    
  var site_url = $('#site_url').val();

   FormDropzone.init();
  FormDropzone2.init();
   FormDropzone3.init();
   $("div#myDropzone3").dropzone({
        url: site_url+'/welcome/send_img/'+$('#user_id').val()+'/'+$('#admin').val()+'/'+$('#sender_name').val()+'/'+$('#role').val()

         // url : "/upload.php?receiver="+id
      });
    $("a#myDropzone2").dropzone({
        url: site_url+'/welcome/upload_profile_pic/'+$('#user_id').val()

         // url : "/upload.php?receiver="+id
      });
});