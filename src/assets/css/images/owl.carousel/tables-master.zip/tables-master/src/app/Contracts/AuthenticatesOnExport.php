<?php

namespace LaravelEnso\Tables\app\Contracts;

interface AuthenticatesOnExport
{
}
