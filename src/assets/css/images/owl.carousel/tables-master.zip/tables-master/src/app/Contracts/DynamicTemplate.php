<?php

namespace LaravelEnso\Tables\app\Contracts;

interface DynamicTemplate
{
    public function cachePrefix(): string;
}
