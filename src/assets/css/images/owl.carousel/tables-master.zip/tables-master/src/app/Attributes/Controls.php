<?php

namespace LaravelEnso\Tables\app\Attributes;

class Controls
{
    public const List = ['columns', 'length', 'reload', 'reset', 'style'];
}
