<?php

namespace LaravelEnso\Tables\app\Attributes;

class Style
{
    public const Table = ['bordered', 'compact', 'hover', 'striped'];

    public const Align = ['center', 'left', 'right'];
}
