<?php

return [
    'apiVersion' => '3.2',
];
