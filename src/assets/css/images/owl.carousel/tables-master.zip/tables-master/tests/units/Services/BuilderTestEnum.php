<?php

namespace LaravelEnso\Tables\Tests\units\Services;

use LaravelEnso\Enums\app\Services\Enum;

class BuilderTestEnum extends Enum
{
    public const Red = 1;
    public const Blue = 2;
}
