<template>
  <div>
    <h1>Page Not Found</h1>
  </div>
</template>

<style scoped>
h1 {
  color: red
}
</style>

<script>
</script>
