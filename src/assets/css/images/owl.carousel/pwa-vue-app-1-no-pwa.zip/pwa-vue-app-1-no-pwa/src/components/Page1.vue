<template>
  <div>
    <h1>Page 1</h1>
  </div>
</template>

<style scoped>
h1 {
  color: green
}
</style>

<script>
</script>
