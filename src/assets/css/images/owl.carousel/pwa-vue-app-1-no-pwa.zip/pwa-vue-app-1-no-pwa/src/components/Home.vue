<template>
  <div>
    <h1>Home</h1>
  </div>
</template>

<style scoped>
h1 {
  color: blue
}
</style>

<script>
</script>
