<?php
if (!defined('sugarEntry') || !sugarEntry) {
    die('Not A Valid Entry Point');
}

$suitecrm_version = '7.11.10';
$suitecrm_timestamp = '2019-11-11 17:00:00';
