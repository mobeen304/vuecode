@extends('layouts.app')

@section('content')
<chat-component></chat-component>
@endsection
